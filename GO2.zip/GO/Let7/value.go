package main

import (
  "fmt"
)

func main(){
  days := 365.2425
  time := 60
  text := "test"
  bool := true
  fmt.Printf("%T: %[1]v \n",days)//float64: 365.2425
  //[n]を使って呼び出すことも可能 ,以降の配列
  fmt.Printf("%[2]T:%[2]v %[1]v\n",days,time)//60 365.2425
  fmt.Printf("%T\n",text)
  fmt.Printf("%T\n",bool)
}
