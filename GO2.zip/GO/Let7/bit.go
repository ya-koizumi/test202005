package main

import (
  "fmt"
  "math/big"
)

func main(){
  var time uint32 = 4240000000
  var x uint16 = 65535
  var xx = 0x20//16進数
  fmt.Printf("%b \n",time)//
  fmt.Printf("%08b \n",x)
  fmt.Printf("0x%x \n",xx)//16進数表記
  fmt.Printf("%v \n",xx)//10進数表記
  fmt.Printf("%08b \n",xx)//bit表示
  xx++
  fmt.Printf("%08b \n",xx)//bit表示
  xx = xx>>2//右シフト 省略形は使えない様子
  fmt.Printf("%08b \n",xx)//bit表示

  //big Int
  //セット方法は2種類
  bigint := big.NewInt(2400)//こっちは型はbigだがInt64しか入れられない
  bigint2 := new(big.Int)
  bigint2.SetString("24000000000000000000",10)//第2引数は進数　これは10進数
  fmt.Println(bigint);
  fmt.Println(bigint2);
  // bigint2 += 10; ただしあふれるから計算もできない
  // fmt.Println(bigint2);
  bigfloat := big.NewFloat(10.02);
  bigfloat.SetString("10.0101010100202020201")
  fmt.Println(bigfloat);

}
