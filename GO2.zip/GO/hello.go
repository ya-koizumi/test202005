//パッケージ宣言
package main
//fmtをimportして使えるようにする
import "fmt"

func main() {
	fmt.Println("Start Go");
}
