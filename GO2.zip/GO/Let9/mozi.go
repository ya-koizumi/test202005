package main

import (
  "fmt"
)

func main(){
  fmt.Println("test\ntest\\n")//\\でエスケープ可能

  // fmt.Println('test2\ntest2\n');//シングルクォーテーション使用不可
  fmt.Println(`test2\ntest2\n`)//goはバッククォートでもエスケープ可能
  var pi rune = 960
  fmt.Printf("%c",pi)//アスキーコード960はπ アスキーコード変換（Unicodeポイント変換？）
  fmt.Println(string(pi))//これでも可能
  var single = 'a'
  fmt.Println(single)//97 アスキーコードポイントか！
  var double = "a20"
  fmt.Printf("%v:%v:%[2]c\n",double,double[2])//配列のピンポイント指定も可能（ただしアスキーコードポイント表記、、）
  fmt.Printf("%U %[1]c",single)//%UはUnicode表記 U+0061 %cはアスキーコードポイント変換のことか。。
  //double[2] = "s" //こういった変換はできないので注意
}
