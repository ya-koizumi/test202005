package main

import (
  "fmt"
)

func main(){
  var poem = "I can" + " fly" //文字列連結は+ なおgoは数値をそのまま入れられない
  fmt.Printf("%v"+"\n",poem)//%UはUnicode表記 U+0061 %cはアスキーコードポイント変換のことか。。
  var ints = 10
  var floats = float64(ints) + 0.1
  fmt.Println(float64(floats))//型変換
  floats += 0.1
  fmt.Println(int(floats))//戻すと小数点カット

  //結構便利？な出力内容を文字列に戻すメソッド
  output := fmt.Sprintf("%v! Lenton",poem)
  fmt.Println(output)
}
