//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"time"
)

func main() {
		var count = 0
		for count < 10{
			fmt.Println(count)
			time.Sleep(time.Second)
			count++;
			if(count > 5){
				break
			}
		}
			fmt.Println("End")
}
