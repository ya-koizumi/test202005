//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"strings"
)

func main() {
	fmt.Println("Start Go")
	var command = "stop go"
	fmt.Println("Stop:",strings.Contains(command,"stop"))
  var value = 10
	var judge = value < 0
	var mathjudge = 1 == 1
  fmt.Println("MathJudge: ",value)
	fmt.Printf("MathJudge: %v\n",judge)
	fmt.Println("MathJudge: ",mathjudge)
}
