//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
)

func main() {
		var character = "amu"
		if character == "snake"{
			fmt.Println("Metal Gear Solid")
		} else if character == "amuro"{
			fmt.Println("Gundom")
		} else {
			fmt.Println("I don't know")
		}
}
