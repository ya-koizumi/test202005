//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"math/rand"
)

func main() {
	var weapon = "beam rifle"
	switch weapon{
	case "beam rifle":
		fmt.Println("100")
	case "bazuka":
		fmt.Println("200")
	default:
		fmt.Println("0")
	}
	var value = rand.Intn(10);
	switch value{
	case 1:
		fmt.Println("Damage:100")
		value++
		//goではfallthroughしないと下のcaseには落ちない
		fallthrough
	case 2:
		fmt.Println("Damage:200")
		value++
	case 3,4,5:
			fmt.Println("Damage:300")
	default:
		fmt.Println("Damage:0")
	}
	//こちらも可能
	switch mobile := "docomo"; mobile{
	case "docomo":
		fmt.Println("Docomo")
	case "au":
		fmt.Println("Au")
	}
}
