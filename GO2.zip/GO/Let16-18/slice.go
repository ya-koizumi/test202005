package main

import (
  "fmt"
  "reflect"
  "sort"
)

func main(){
//前提としてsliceは配列をビュー化して中のものを分割する技術
//goは配列を指定せずに作ったスライス []string等は裏で配列を作成している
//goでは配列は制約が多いのと使える関数の観点？から一般的にスライスを使う

//複数文字列 ...はコンパイラでの配列長自動計算
  squareEnixlists := [...]string{
    "kingdamharts",
    "kingdamharts2",
    "finalfantasy",
    "finalfantasy2",
    "kingdamharts",
    "kingdamharts2",//カンマ終わりであること
  }
  fmt.Println(squareEnixlists[0:2]) //0から配列長2個分をスライス
  fmt.Println(squareEnixlists[2:4]) //インデックス長2から4番目未満をスライス
// 　fmt.Println(squareEnixlists[:4])//省略すれば0扱い なぜかこっち動かない。。
  fmt.Println(squareEnixlists[:])//省略すれば0扱い
  fmt.Println(len(squareEnixlists)) //スライスもスライス長を求める方式は同じ
  //配列からでなくスライス型のstringを直接作ることも可能
  twoD := []string{"Btest", "Btest2",
    "Atest", "test3"}
  fmt.Println("Cnt:",len(twoD))
  sort.StringSlice(twoD).Sort() //昇順ｿｰﾄ StringSlizeの引数はスライス
  fmt.Println(twoD)
  fmt.Println(reflect.TypeOf(twoD))
  //同意
  squareSlice := squareEnixlists[:]
  sort.StringSlice(squareSlice).Sort()
  fmt.Println(squareSlice)
  fmt.Println(reflect.TypeOf(squareSlice))
}
