package main

import (
  "fmt"
  // "reflect"
  // "sort"
)

func main(){
//操作系
  squareEnixlists := []string{
    "kingdamharts",
    "kingdamharts2",
    "finalfantasy",
    "finalfantasy2",
    "kingdamharts",
    "kingdamharts2"}
  fmt.Println("Cap:",cap(squareEnixlists))//容量が見れる？
  //追加
  squareEnixlists = append(squareEnixlists, "Saint Sord3")
  fmt.Println("Cnt:",len(squareEnixlists))
  fmt.Println("Cap:",cap(squareEnixlists))//12　デフォルトの容量を超えた場合2倍の容量を確保する習性がある
  //記載省略だが配列からスライス作成の際は[0:4:4]と第3の容量まで指定する方がよい
  //子の場合超えたら無視されるようになる　まあ保険かな
  //配列の容量をあらかじめ確保する場合は
  squareMakeList := make([]string, 0, 10) //容量指定してスライス作成
  squareMakeList = append(squareMakeList,
      "kingdamharts",
      "kingdamharts2",
      "finalfantasy",
      "finalfantasy2",
      "kingdamharts",
      "kingdamharts2")
    //追加
    squareEnixlists = append(squareMakeList, "Saint Sord3")
    fmt.Println("Cnt:",len(squareMakeList))
    fmt.Println("Cap:",cap(squareMakeList))
}
