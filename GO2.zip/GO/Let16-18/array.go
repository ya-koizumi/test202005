package main

import (
  "fmt"
)

func main(){
  var finalfantasylist [3]string
  finalfantasylist[0] = "finalfantasy"
  finalfantasylist[1] = "finalfantasyⅡ"
  fmt.Println(finalfantasylist)
  fmt.Println(finalfantasylist[0])
  fmt.Println(finalfantasylist[2])//""
  fmt.Println(len(finalfantasylist))

//   dragonquest := [3]string{"dragonquest", "dragonquestⅡ"} これ動かんな。。まあいらんか
// 　fmt.Println(len(dragonquest))

//複数文字列 ...はコンパイラでの配列長自動計算
  kingdamharts := [...]string{
    "kingdamharts",
    "kingdamhartsⅡ",//カンマ終わりであること
  }
  fmt.Println(kingdamharts)//かっこ引っ付くな。。
  fmt.Println(kingdamharts[0])

  //ループ処理ではrangeという書き方もできる
  for i := 0; i < len(kingdamharts); i++ {
    fmt.Println(kingdamharts[i])
  }
  //同意味　これはどうやらrange関数の返り値が配列番号、要素になっている様子
  //これあれかforeachみたいにもつかえるな
  for i2, finalfantasy := range finalfantasylist{
    fmt.Println(i2,finalfantasy)
  }
  //  ff := finalfantas y//ちなみにgoは配列をそのまま変数に入れるとポインタ渡しでなく値のコピーになる

　//2次元配列
  var a[2][2]string
  a[0][0] = "tets"
  //スライス多次元配列　goはスライス配列を宣言すると裏で配列を作成してそれに対するスライスを作成している
  twoD := [][]string{
    {"test",
      "test2",
      "test3"},
    {"Btest",
      "Btest2",
      "test3"}}//最後のかっこは改行すると落ちる
  fmt.Println("Cnt:",len(twoD))

}
