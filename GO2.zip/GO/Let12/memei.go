package main

import (
  "fmt"
)

//無名関数
var f = func(s string){
  fmt.Println(s)
}

func main(){
  f("papico");
  //内部呼び出し
  v := func() int{
    return 1
  }
  var in = v()
  fmt.Println(in)
  //直呼び出しパターン
  func(){
    fmt.Println("test")
  }()

}
