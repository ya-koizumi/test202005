package main

import (
  "fmt"
  "strconv"
)

//struct型作成　いわばリスト
//goは大文字スタートのメソッドはpublic扱い 小文字はprivate扱い
type Flute struct {
  flutetype string
  value int
}
//goは2つreturnできる！！
func test(input int)(i int, i2 int){
  return input+10, input*10
}


//type関数版
//関数型変数生成 これ単体で使うというよりこういう型を持つ関数を別名で生成するといういみが正しい
type capseltest func(int)(int,int)

func main(){
  //2つのreturnテスト
  a, b:= test(10)
  fmt.Println(a,b)
  fmt.Println(test(30))

  // fmt.Println(capseltest(10)) 使い方さっぱりわからん。。

  //レシーバーテスト
  //値をセット
  fluteset := Flute{"apple", 100}
  fmt.Println(fluteset.reciever())
  //構造体復習　こういった設定も可能

  //ちなみにgoでは初期化関数を作るのが一般的だそう
  fluteset2 := newFlute("banana",1000)
  fmt.Println(fluteset2.reciever())

  s := typefunc()
  cd,de := s(10)
  fmt.Println(cd,de)

  s2 := typefunc2()
  fmt.Println(s2(15))
}
//ちなみにgoはクラス、オブジェクトは作れない
//その代わりレシーバーがある
//レシーバーはいわばクラスとメソッドを作るイメージになる

//頭のレシーバーが配属するクラスみたいなものになる
//これだとfluteの中にあるメソッドという配属になる

//※レシーバーに指定できるのはtype型のみなところがポイント
func (i Flute) reciever() string{
  //intは出せないのでASCII変換
  return "フルーツ名:"+i.flutetype+" 値段:"+strconv.Itoa(i.value)
}
//*は多分ポインタ？
func newFlute(flutetype string, value int) *Flute{
  fl := new(Flute)
  fl.flutetype = flutetype
  fl.value = value
  return fl;
}

//capseltestを返すということはfunc(input int)(ret1 int,ret2 int)を返すということになる
func typefunc() capseltest{
  return func(input int)(ret1 int,ret2 int){
    return input+10000, input+20000
  }
}
//つまりこれはこれと一緒
func typefunc2() func(int)(int,int){
  return func(input int)(ret1 int,ret2 int){
    return input+10000, input+20000
  }
}
