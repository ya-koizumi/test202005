package main

import "fmt"

func main() {
	var num int = 2
	var pow int
	var result = 1
	num = 2
	pow = 4
	for i := 0; i < pow; i++{
		result *= num
	}

	fmt.Printf("%dの%d乗は%dです。\n", num, pow, result)
	fmt.Printf("%f",149 * 3.141592)
	fmt.Println(num,":",pow)
}
