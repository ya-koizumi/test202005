//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"math"
)

func main() {
	var loopcnt float64= 100.121;
	fmt.Println(loopcnt);
	//文字列長.小数の桁数
	//文字列長は実地より小さい場合無視される　大きい場合はスペースで足される
	//小数の桁数は小さい場合は有効数のみ表示。大きい場合は0で足される
	fmt.Printf("%2.2f\n", loopcnt)//100.12
	fmt.Printf("%8.3f\n", loopcnt)// 100.121
	fmt.Printf("%7.5f\n", loopcnt)//100.12100
	fmt.Printf("%08.3f\n", loopcnt)//0100.121

	fmt.Println("近似値テスト")
	var third = 1.0/3.0
	fmt.Println(third+third+third)
	fmt.Println(0.1+0.2)
	var bank = 0.1
	 bank = bank+0.2//IEEE754の規定で小数点計算すると丸め誤差が発生して狂う
	fmt.Println(bank)
	fmt.Println(math.Abs(bank))//絶対値表示
	fmt.Println(math.Abs(bank+0.2))//絶対値表示
}
