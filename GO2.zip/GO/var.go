package main

import "fmt"
import "math/rand"

func main(){
  const LIGHTSPEED = 299742
  //まとめて宣言可能
  var (
    distance = 2000
    dist = 200
  )
  fmt.Printf("%d\n",(int)(distance/dist));
  //++distance 出来ない
  distance++
  fmt.Println(distance);
//  fmt.Println(distance++); 中に入れるのもできない

  //乱数
  var num = rand.Intn(10) + 1
  fmt.Println(num)
  num += rand.Intn(5)
  fmt.Println(num)
}
