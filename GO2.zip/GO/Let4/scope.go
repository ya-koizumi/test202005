//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"math/rand"
)

func main() {
	var loopcnt = 100;
	for loopcnt = 10; loopcnt > 0; loopcnt-- {
		var rands = rand.Intn(10)
		fmt.Println(rands);
	}
	for loops := 10; loops > 0; loops-- {
		var rands = rand.Intn(10) + 10
		fmt.Println(rands);
	}
	// こちらは実行不可
	// fmt.Println(loops);
	fmt.Println(loopcnt);
}
