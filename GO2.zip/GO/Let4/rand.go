//パッケージ宣言
package main
//fmtをimportして使えるようにする
import (
"fmt"
"math/rand"
)

func main() {
	var loopcnt = 0;
	var rands = 1;
	for loopcnt < 10 {
		rands = rand.Intn(10)
		fmt.Println(rands);
		loopcnt++;
	}
}
